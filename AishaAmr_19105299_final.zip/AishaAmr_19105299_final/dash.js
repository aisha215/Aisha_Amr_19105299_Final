const express = require('express');
const bodyParser = require('body-parser');
const ejs = require('ejs'); 
const mysql = require('mysql2');
const session = require('express-session');

const app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.set('view engine', 'ejs');

// Create a MySQL connection
const connection = mysql.createConnection({
    host: '127.0.0.1', // MySQL host
    user: 'root', // MySQL username
    password: '', // MySQL password
    database: 'Database_final' // MySQL database name
  });
  
  // Connect to the database
  connection.connect((err) => {
    if (err) {
      console.error('Error connecting to database:', err);
      return;
    }
    console.log('Connected to MySQL database');
  });
  //////////////////////////////////////////////////////////////////////////////////////
  // Set up session middleware
app.use(
    session({
      secret: 'Database_final',
      resave: true,
      saveUninitialized: true
    })
  );
  
  //create database for employees 
  var sql = "CREATE TABLE Employees (Id INT, Username NVARCHAR(255), Password NVARCHAR(255), DepartmentID INT);";
  con.query(sql, function (err, result) {
    if (err) throw err;
    console.log("Employees table created");
  });
//create DB for dep
sql = "CREATE TABLE Departments (Id INT, Name NVARCHAR(255));";
con.query(sql, function (err, result) {
  if (err) throw err;
  console.log("Departments table created");
});

//creat db for log
sql = "CREATE TABLE Log (Id INT, Username NVARCHAR(255), LoginDate DATETIME);";
  con.query(sql, function (err, result) {
    if (err) throw err;
    console.log("Log table created");
  });


app.get('/', (req, res) => {
    if (req.session.loggedin) {
        res.redirect('/dashboard');
      } else {
        res.send('/index');
      }
});
//d.	Dashboard and login history screen will have a session check if session value “loggedin” equal true then it will return the screen. If false it will return the index screen
app.get('/dashboard', function(req, res) {
    if (req.session.loggedin) {
      res.send('/dashbord');
    } else {
      res.redirect('/');
    }
  });

app.post('/api/login', (req, res) => {
    const { username, password ,department } = req.body;

    connection.query("SELECT * FROM Employees where Username = ? AND Password = ?  AND department=?", [username, password,department], (err, results) => {
      if (err) {
        console.error('Error fetching users:', err);
        res.status(500).json({ success: false, message: 'Error fetching users' });
        return;
      }
      if (results.length > 0){
        req.session.loggedin = true;
        req.session.username = username;
        res.redirect('/users'); 
      } else {
        res.status(500).json({ success: false, message: 'Authentication failed' });
      }
      
    });
});

app.post('/api/logout', function(req, res) {
    req.session.destroy();
    res.send(true);
  });

  app.post('/api/adddepartment', function(req, res) {
    var name = req.body.name;
    con.query('INSERT INTO Departments (Name) VALUES (?)', [name]);
    res.send(true);
  });


app.post('/api/adduser', (req, res) => {
    const { username, password ,department } = req.body;
    const { departmentid, departmentname } = req.body2;
    connection.query(
      'INSERT INTO Employees (username, password,department ) VALUES (?, ?,?)',
      [username, password,department ],
      (err, result) => {
        if (err) {
          console.error('Error inserting data:', err);
          res.status(500).json({ error: 'Error inserting data' });
          return;
        }
  
        if(result.affectedRows == 1)
          res.status(200).json({ success: true, id: result.insertId, username: username, password: password ,department :department  });
      }


    );
     
    connection.query(
    'INSERT INTO Departments (departmentid, departmentname ) VALUES (?,?)',
    [departmentid, departmentname  ],
    (err, result) => {
      if (err) {
        console.error('Error inserting data:', err);
        res.status(500).json({ error: 'Error inserting data' });
        return;
      }

      if(result.affectedRows == 1)
        res.status(200).json({ success: true, id: result.insertId, username: username, password: password ,department :department  });
    })
  });

  app.post('/api/deleteuser', (req, res) => {
    const { username, password ,department } = req.body;
    
    con.query('DELETE FROM Employees WHERE username = ?', [username]);
  res.send(true);
});
  
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
  console.log("http://localhost:3000");
}); 
